#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 27 21:13:13 2020

@author: naoyatoyoshima
"""


